import { Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { SuggestionsComponent } from './components/suggestions/suggestions.component';
import { MenuComponent } from './components/menu/menu.component';
import { SettingsComponent } from './components/settings/settings.component';
import { AdminDashboardComponent } from './components/admin/admin-dashboard/admin-dashboard.component';
import { AdminMenuComponent } from './components/admin/admin-menu/admin-menu.component';
import { AdminTransactionsComponent } from './components/admin/admin-transactions/admin-transactions.component';
import { AdminGuard } from './guards/admin.guard';

export const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  { path: 'suggestions', component: SuggestionsComponent },
  { path: 'menu', component: MenuComponent },
  { path: 'settings', component: SettingsComponent },
  { 
    path: 'admin',
    canActivate: [AdminGuard],
    children: [
      { path: '', component: AdminDashboardComponent },
      { path: 'menu', component: AdminMenuComponent },
      { path: 'transactions', component: AdminTransactionsComponent }
    ]
  }
];