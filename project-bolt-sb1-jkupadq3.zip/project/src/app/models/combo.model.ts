export interface Combo {
  id: number;
  name: string;
  items: MenuItem[];
  totalPrice: number;
  category: 'breakfast' | 'lunch' | 'snacks' | 'dinner';
}