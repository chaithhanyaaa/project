export interface MenuItem {
  id: number;
  name: string;
  price: number;
  description: string;
  category: 'breakfast' | 'lunch' | 'snacks' | 'dinner';
}