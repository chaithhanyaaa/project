import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { MenuItem } from '../models/menu-item.model';

@Injectable({
  providedIn: 'root'
})
export class MenuService {
  private menuItems: MenuItem[] = [
    {
      id: 1,
      name: 'Breakfast Combo 1',
      price: 5.99,
      description: 'Eggs, Toast, Coffee',
      category: 'breakfast'
    },
    {
      id: 2,
      name: 'Lunch Special',
      price: 8.99,
      description: 'Sandwich, Soup, Drink',
      category: 'lunch'
    },
    {
      id: 3,
      name: 'Afternoon Snack',
      price: 3.99,
      description: 'Fruit Bowl, Yogurt',
      category: 'snacks'
    },
    {
      id: 4,
      name: 'Dinner Plate',
      price: 10.99,
      description: 'Grilled Chicken, Rice, Vegetables',
      category: 'dinner'
    }
  ];

  private menuItemsSubject = new BehaviorSubject<MenuItem[]>(this.menuItems);

  constructor() {
    // Load initial menu items from localStorage
    const savedItems = localStorage.getItem('menuItems');
    if (savedItems) {
      this.menuItems = JSON.parse(savedItems);
      this.menuItemsSubject.next(this.menuItems);
    } else {
      // Save default items if none exist
      this.saveToStorage();
    }
  }

  getMenuItems(): Observable<MenuItem[]> {
    return this.menuItemsSubject.asObservable();
  }

  getMenuItemsByCategory(category: string): MenuItem[] {
    return this.menuItems.filter(item => item.category === category);
  }

  addMenuItem(item: MenuItem) {
    this.menuItems.push(item);
    this.saveToStorage();
    this.menuItemsSubject.next([...this.menuItems]);
  }

  deleteMenuItem(id: number) {
    this.menuItems = this.menuItems.filter(item => item.id !== id);
    this.saveToStorage();
    this.menuItemsSubject.next([...this.menuItems]);
  }

  private saveToStorage() {
    localStorage.setItem('menuItems', JSON.stringify(this.menuItems));
  }
}