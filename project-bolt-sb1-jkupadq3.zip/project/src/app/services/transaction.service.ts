import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

interface Transaction {
  id: number;
  itemName: string;
  amount: number;
  timestamp: Date;
}

@Injectable({
  providedIn: 'root'
})
export class TransactionService {
  private transactions: Transaction[] = [];
  private transactionsSubject = new BehaviorSubject<Transaction[]>([]);

  constructor() {
    // Load initial transactions from localStorage
    const savedTransactions = localStorage.getItem('transactions');
    if (savedTransactions) {
      this.transactions = JSON.parse(savedTransactions);
      this.transactionsSubject.next(this.transactions);
    }
  }

  getTransactions(): Observable<Transaction[]> {
    return this.transactionsSubject.asObservable();
  }

  addTransaction(itemName: string, amount: number) {
    const transaction: Transaction = {
      id: Date.now(),
      itemName,
      amount,
      timestamp: new Date()
    };
    
    this.transactions.push(transaction);
    localStorage.setItem('transactions', JSON.stringify(this.transactions));
    this.transactionsSubject.next([...this.transactions]);
  }
}