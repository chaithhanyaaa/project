import { Injectable } from '@angular/core';
import { Observable, map } from 'rxjs';
import { Combo } from '../models/combo.model';
import { MenuService } from './menu.service';
import { BalanceService } from './balance.service';
import { endOfMonth, differenceInDays } from 'date-fns';

@Injectable({
  providedIn: 'root'
})
export class SuggestionsService {
  constructor(
    private menuService: MenuService,
    private balanceService: BalanceService
  ) {}

  getSuggestions(): Observable<Combo[]> {
    return this.balanceService.getBalance().pipe(
      map(balance => {
        const daysLeft = this.getDaysLeftInMonth();
        const dailyBudget = balance / daysLeft;
        return this.generateCombos(dailyBudget);
      })
    );
  }

  private getDaysLeftInMonth(): number {
    const today = new Date();
    const lastDay = endOfMonth(today);
    return differenceInDays(lastDay, today) + 1;
  }

  private generateCombos(dailyBudget: number): Combo[] {
    const combos: Combo[] = [];
    const categories: ('breakfast' | 'lunch' | 'snacks' | 'dinner')[] = 
      ['breakfast', 'lunch', 'snacks', 'dinner'];

    categories.forEach((category, index) => {
      const items = this.menuService.getMenuItemsByCategory(category);
      const affordableItems = items.filter(item => item.price <= dailyBudget / 4);

      if (affordableItems.length > 0) {
        combos.push({
          id: index + 1,
          name: `${category.charAt(0).toUpperCase() + category.slice(1)} Combo`,
          items: [affordableItems[0]],
          totalPrice: affordableItems[0].price,
          category: category
        });
      }
    });

    return combos;
  }
}