import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

export interface Notification {
  id: number;
  message: string;
  type: 'info' | 'warning' | 'error';
  timestamp: Date;
}

@Injectable({
  providedIn: 'root'
})
export class NotificationsService {
  private notifications: Notification[] = [];
  private notificationsSubject = new BehaviorSubject<Notification[]>([]);

  getNotifications(): Observable<Notification[]> {
    return this.notificationsSubject.asObservable();
  }

  addNotification(message: string, type: 'info' | 'warning' | 'error' = 'info') {
    const notification: Notification = {
      id: Date.now(),
      message,
      type,
      timestamp: new Date()
    };
    this.notifications.push(notification);
    this.notificationsSubject.next([...this.notifications]);
  }

  removeNotification(id: number) {
    this.notifications = this.notifications.filter(n => n.id !== id);
    this.notificationsSubject.next([...this.notifications]);
  }

  clearAll() {
    this.notifications = [];
    this.notificationsSubject.next([]);
  }
}