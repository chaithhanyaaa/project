import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private adminKey = 'isAdmin';
  private isAdminSubject = new BehaviorSubject<boolean>(this.getInitialAdminStatus());

  constructor() {}

  private getInitialAdminStatus(): boolean {
    return localStorage.getItem(this.adminKey) === 'true';
  }

  login(password: string): boolean {
    // Simple admin authentication for demo purposes
    if (password === 'admin123') {
      localStorage.setItem(this.adminKey, 'true');
      this.isAdminSubject.next(true);
      return true;
    }
    return false;
  }

  logout() {
    localStorage.removeItem(this.adminKey);
    this.isAdminSubject.next(false);
  }

  isAdmin(): boolean {
    return this.isAdminSubject.value;
  }
}