import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BalanceService {
  private balanceKey = 'studentBalance';
  private balanceSubject = new BehaviorSubject<number>(this.getInitialBalance());

  constructor() {}

  private getInitialBalance(): number {
    const savedBalance = localStorage.getItem(this.balanceKey);
    return savedBalance ? parseFloat(savedBalance) : 0;
  }

  getBalance() {
    return this.balanceSubject.asObservable();
  }

  updateBalance(amount: number) {
    localStorage.setItem(this.balanceKey, amount.toString());
    this.balanceSubject.next(amount);
  }

  deductBalance(amount: number) {
    const currentBalance = this.balanceSubject.value;
    const newBalance = currentBalance - amount;
    if (newBalance >= 0) {
      this.updateBalance(newBalance);
      return true;
    }
    return false;
  }
}