import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MenuItem } from '../../models/menu-item.model';
import { MenuService } from '../../services/menu.service';
import { BalanceService } from '../../services/balance.service';
import { NotificationsService } from '../../services/notifications.service';

@Component({
  selector: 'app-menu',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="menu-container">
      <h2>Menu Items</h2>
      
      <div class="category-tabs">
        <button 
          *ngFor="let cat of categories" 
          [class.active]="selectedCategory === cat"
          (click)="selectCategory(cat)">
          {{ cat | titlecase }}
        </button>
      </div>

      <div class="items-grid">
        <div *ngFor="let item of filteredItems" class="menu-item">
          <h3>{{ item.name }}</h3>
          <p class="description">{{ item.description }}</p>
          <p class="price">{{ item.price | currency }}</p>
          <button (click)="purchaseItem(item)">Go Ahead</button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .menu-container {
      padding: 20px;
      max-width: 1200px;
      margin: 0 auto;
    }

    .category-tabs {
      display: flex;
      gap: 10px;
      margin-bottom: 20px;
      overflow-x: auto;
      padding-bottom: 10px;
    }

    .category-tabs button {
      padding: 10px 20px;
      border: none;
      border-radius: 4px;
      background-color: #eee;
      cursor: pointer;
      white-space: nowrap;
    }

    .category-tabs button.active {
      background-color: #3498db;
      color: white;
    }

    .items-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 20px;
    }

    .menu-item {
      background: white;
      border-radius: 8px;
      padding: 20px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    .description {
      color: #666;
      margin: 10px 0;
    }

    .price {
      font-size: 1.2em;
      font-weight: bold;
      color: #2c3e50;
      margin: 15px 0;
    }

    button {
      width: 100%;
      padding: 10px;
      background-color: #3498db;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    button:hover {
      background-color: #2980b9;
    }
  `]
})
export class MenuComponent implements OnInit {
  menuItems: MenuItem[] = [];
  filteredItems: MenuItem[] = [];
  categories: ('breakfast' | 'lunch' | 'snacks' | 'dinner')[] = 
    ['breakfast', 'lunch', 'snacks', 'dinner'];
  selectedCategory: string = 'breakfast';

  constructor(
    private menuService: MenuService,
    private balanceService: BalanceService,
    private notificationsService: NotificationsService
  ) {}

  ngOnInit() {
    this.menuService.getMenuItems().subscribe(
      items => {
        this.menuItems = items;
        this.filterItems();
      }
    );
  }

  selectCategory(category: string) {
    this.selectedCategory = category;
    this.filterItems();
  }

  private filterItems() {
    this.filteredItems = this.menuItems.filter(
      item => item.category === this.selectedCategory
    );
  }

  purchaseItem(item: MenuItem) {
    if (this.balanceService.deductBalance(item.price)) {
      this.notificationsService.addNotification(
        `Successfully purchased ${item.name}`,
        'info'
      );
    } else {
      this.notificationsService.addNotification(
        'Insufficient balance for this item',
        'error'
      );
    }
  }
}