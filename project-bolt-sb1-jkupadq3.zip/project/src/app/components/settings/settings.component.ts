import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NotificationsService, Notification } from '../../services/notifications.service';

@Component({
  selector: 'app-settings',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="settings-container">
      <h2>Settings</h2>
      
      <section class="theme-section">
        <h3>Theme</h3>
        <div class="theme-options">
          <button (click)="setTheme('light')" [class.active]="currentTheme === 'light'">
            Light
          </button>
          <button (click)="setTheme('dark')" [class.active]="currentTheme === 'dark'">
            Dark
          </button>
        </div>
      </section>

      <section class="notifications-section">
        <h3>Notifications</h3>
        <div class="notifications-list">
          <div *ngFor="let notification of notifications" 
               class="notification-item"
               [class]="notification.type">
            <p>{{ notification.message }}</p>
            <small>{{ notification.timestamp | date:'short' }}</small>
            <button class="clear-btn" (click)="removeNotification(notification.id)">
              Clear
            </button>
          </div>
        </div>
        <button *ngIf="notifications.length > 0" 
                class="clear-all-btn"
                (click)="clearAllNotifications()">
          Clear All Notifications
        </button>
      </section>
    </div>
  `,
  styles: [`
    .settings-container {
      padding: 20px;
      max-width: 800px;
      margin: 0 auto;
    }

    section {
      background: white;
      border-radius: 8px;
      padding: 20px;
      margin-bottom: 20px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    h3 {
      margin-bottom: 15px;
      color: #2c3e50;
    }

    .theme-options {
      display: flex;
      gap: 10px;
    }

    .theme-options button {
      padding: 10px 20px;
      border: 1px solid #ddd;
      background: white;
    }

    .theme-options button.active {
      background-color: #3498db;
      color: white;
      border-color: #3498db;
    }

    .notifications-list {
      margin-top: 15px;
    }

    .notification-item {
      padding: 15px;
      border-radius: 4px;
      margin-bottom: 10px;
      position: relative;
    }

    .notification-item.info {
      background-color: #d1ecf1;
      color: #0c5460;
    }

    .notification-item.warning {
      background-color: #fff3cd;
      color: #856404;
    }

    .notification-item.error {
      background-color: #f8d7da;
      color: #721c24;
    }

    .clear-btn {
      position: absolute;
      right: 10px;
      top: 50%;
      transform: translateY(-50%);
      padding: 5px 10px;
      background: transparent;
      border: 1px solid currentColor;
      color: inherit;
      opacity: 0.7;
    }

    .clear-btn:hover {
      opacity: 1;
    }

    .clear-all-btn {
      width: 100%;
      margin-top: 15px;
      padding: 10px;
      background-color: #e74c3c;
      color: white;
    }

    .clear-all-btn:hover {
      background-color: #c0392b;
    }

    small {
      display: block;
      margin-top: 5px;
      opacity: 0.7;
    }
  `]
})
export class SettingsComponent {
  notifications: Notification[] = [];
  currentTheme: 'light' | 'dark' = 'light';

  constructor(private notificationsService: NotificationsService) {
    this.notificationsService.getNotifications().subscribe(
      notifications => this.notifications = notifications
    );
  }

  setTheme(theme: 'light' | 'dark') {
    this.currentTheme = theme;
    document.body.className = theme;
  }

  removeNotification(id: number) {
    this.notificationsService.removeNotification(id);
  }

  clearAllNotifications() {
    this.notificationsService.clearAll();
  }
}