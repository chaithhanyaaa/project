import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BalanceService } from '../../services/balance.service';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="home-container">
      <h2>Welcome to Food Planner</h2>
      <div class="balance-section">
        <h3>Current Balance</h3>
        <p class="balance">{{ balance | currency }}</p>
        <button (click)="isEditing = true" *ngIf="!isEditing">Edit Balance</button>
        <div *ngIf="isEditing" class="edit-balance">
          <input type="number" [(ngModel)]="newBalance" placeholder="Enter new balance">
          <button (click)="updateBalance()">Save</button>
          <button (click)="cancelEdit()">Cancel</button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .home-container {
      padding: 20px;
      max-width: 800px;
      margin: 0 auto;
    }
    .balance-section {
      margin-top: 20px;
      padding: 20px;
      border: 1px solid #ddd;
      border-radius: 8px;
    }
    .balance {
      font-size: 24px;
      font-weight: bold;
      color: #2c3e50;
    }
    .edit-balance {
      margin-top: 10px;
    }
    button {
      margin: 0 5px;
      padding: 8px 16px;
      border: none;
      border-radius: 4px;
      background-color: #3498db;
      color: white;
      cursor: pointer;
    }
    button:hover {
      background-color: #2980b9;
    }
    input {
      padding: 8px;
      margin-right: 10px;
      border: 1px solid #ddd;
      border-radius: 4px;
    }
  `]
})
export class HomeComponent {
  balance = 0;
  isEditing = false;
  newBalance = 0;

  constructor(private balanceService: BalanceService) {
    this.balanceService.getBalance().subscribe(
      balance => this.balance = balance
    );
  }

  updateBalance() {
    this.balanceService.updateBalance(this.newBalance);
    this.isEditing = false;
  }

  cancelEdit() {
    this.isEditing = false;
    this.newBalance = this.balance;
  }
}