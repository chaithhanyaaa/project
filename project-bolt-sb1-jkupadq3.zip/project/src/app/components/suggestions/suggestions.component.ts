import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Combo } from '../../models/combo.model';
import { SuggestionsService } from '../../services/suggestions.service';
import { BalanceService } from '../../services/balance.service';
import { NotificationsService } from '../../services/notifications.service';

@Component({
  selector: 'app-suggestions',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="suggestions-container">
      <h2>Daily Meal Suggestions</h2>
      
      <div *ngIf="insufficientBalance" class="warning-message">
        Insufficient balance for the month. Please consider adding more funds or adjusting your meal plan.
      </div>

      <div class="combos-grid">
        <div *ngFor="let combo of combos" class="combo-card">
          <h3>{{ combo.name }}</h3>
          <div class="items-list">
            <div *ngFor="let item of combo.items" class="item">
              <span>{{ item.name }}</span>
              <span class="price">{{ item.price | currency }}</span>
            </div>
          </div>
          <p class="total">Total: {{ combo.totalPrice | currency }}</p>
          <button (click)="selectCombo(combo)" [disabled]="insufficientBalance">
            Go Ahead
          </button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .suggestions-container {
      padding: 20px;
      max-width: 1200px;
      margin: 0 auto;
    }

    .warning-message {
      background-color: #fff3cd;
      color: #856404;
      padding: 15px;
      border-radius: 4px;
      margin-bottom: 20px;
    }

    .combos-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 20px;
      margin-top: 20px;
    }

    .combo-card {
      background: white;
      border-radius: 8px;
      padding: 20px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    .items-list {
      margin: 15px 0;
    }

    .item {
      display: flex;
      justify-content: space-between;
      margin: 5px 0;
    }

    .price {
      color: #2c3e50;
      font-weight: bold;
    }

    .total {
      font-size: 1.2em;
      font-weight: bold;
      margin: 15px 0;
    }

    button {
      width: 100%;
      padding: 10px;
      background-color: #3498db;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    button:disabled {
      background-color: #ccc;
      cursor: not-allowed;
    }

    button:hover:not(:disabled) {
      background-color: #2980b9;
    }
  `]
})
export class SuggestionsComponent implements OnInit {
  combos: Combo[] = [];
  insufficientBalance = false;

  constructor(
    private suggestionsService: SuggestionsService,
    private balanceService: BalanceService,
    private notificationsService: NotificationsService
  ) {}

  ngOnInit() {
    this.loadSuggestions();
  }

  private loadSuggestions() {
    this.suggestionsService.getSuggestions().subscribe(
      suggestions => {
        this.combos = suggestions;
        this.insufficientBalance = suggestions.length < 4;
        
        if (this.insufficientBalance) {
          this.notificationsService.addNotification(
            'Insufficient balance for the month. Please add more funds.',
            'warning'
          );
        }
      }
    );
  }

  selectCombo(combo: Combo) {
    if (this.balanceService.deductBalance(combo.totalPrice)) {
      this.notificationsService.addNotification(
        `Successfully purchased ${combo.name}`,
        'info'
      );
    } else {
      this.notificationsService.addNotification(
        'Insufficient balance for this combo',
        'error'
      );
    }
  }
}