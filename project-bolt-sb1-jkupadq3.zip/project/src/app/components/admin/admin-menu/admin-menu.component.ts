import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MenuItem } from '../../../models/menu-item.model';
import { MenuService } from '../../../services/menu.service';
import { NotificationsService } from '../../../services/notifications.service';

@Component({
  selector: 'app-admin-menu',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="admin-menu">
      <h2>Menu Management</h2>

      <div class="add-item-form">
        <h3>Add New Item</h3>
        <div class="form-group">
          <input type="text" [(ngModel)]="newItem.name" placeholder="Item Name">
          <input type="number" [(ngModel)]="newItem.price" placeholder="Price">
          <input type="text" [(ngModel)]="newItem.description" placeholder="Description">
          <select [(ngModel)]="newItem.category">
            <option value="breakfast">Breakfast</option>
            <option value="lunch">Lunch</option>
            <option value="snacks">Snacks</option>
            <option value="dinner">Dinner</option>
          </select>
          <button (click)="addItem()">Add Item</button>
        </div>
      </div>

      <div class="menu-items">
        <h3>Current Menu Items</h3>
        <div class="items-grid">
          <div *ngFor="let item of menuItems" class="menu-item">
            <div class="item-header">
              <h4>{{ item.name }}</h4>
              <button class="delete-btn" (click)="deleteItem(item)">Delete</button>
            </div>
            <p>{{ item.description }}</p>
            <p class="price">{{ item.price | currency }}</p>
            <p class="category">{{ item.category | titlecase }}</p>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .admin-menu {
      padding: 20px;
      max-width: 1200px;
      margin: 0 auto;
    }

    .add-item-form {
      background: white;
      padding: 20px;
      border-radius: 8px;
      margin-bottom: 20px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    .form-group {
      display: grid;
      gap: 10px;
      margin-top: 15px;
    }

    input, select {
      padding: 8px;
      border: 1px solid #ddd;
      border-radius: 4px;
    }

    .items-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 20px;
    }

    .menu-item {
      background: white;
      padding: 15px;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    .item-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 10px;
    }

    .delete-btn {
      background-color: #e74c3c;
      padding: 5px 10px;
      font-size: 0.9em;
    }

    .delete-btn:hover {
      background-color: #c0392b;
    }

    .price {
      font-weight: bold;
      color: #2c3e50;
    }

    .category {
      color: #666;
      font-size: 0.9em;
    }
  `]
})
export class AdminMenuComponent implements OnInit {
  menuItems: MenuItem[] = [];
  newItem: MenuItem = {
    id: 0,
    name: '',
    price: 0,
    description: '',
    category: 'breakfast'
  };

  constructor(
    private menuService: MenuService,
    private notificationsService: NotificationsService
  ) {}

  ngOnInit() {
    this.menuService.getMenuItems().subscribe(
      items => this.menuItems = items
    );
  }

  addItem() {
    if (this.validateItem()) {
      this.newItem.id = Date.now();
      this.menuService.addMenuItem(this.newItem);
      this.notificationsService.addNotification('Menu item added successfully', 'info');
      this.resetForm();
    } else {
      this.notificationsService.addNotification('Please fill all fields correctly', 'error');
    }
  }

  deleteItem(item: MenuItem) {
    this.menuService.deleteMenuItem(item.id);
    this.notificationsService.addNotification('Menu item deleted successfully', 'info');
  }

  private validateItem(): boolean {
    return !!(
      this.newItem.name &&
      this.newItem.price > 0 &&
      this.newItem.description &&
      this.newItem.category
    );
  }

  private resetForm() {
    this.newItem = {
      id: 0,
      name: '',
      price: 0,
      description: '',
      category: 'breakfast'
    };
  }
}