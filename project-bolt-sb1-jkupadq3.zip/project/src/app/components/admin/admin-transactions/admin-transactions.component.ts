import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TransactionService } from '../../../services/transaction.service';

interface Transaction {
  id: number;
  itemName: string;
  amount: number;
  timestamp: Date;
}

@Component({
  selector: 'app-admin-transactions',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="admin-transactions">
      <h2>Transaction History</h2>

      <div class="transactions-stats">
        <div class="stat-card">
          <h3>Total Transactions</h3>
          <p>{{ transactions.length }}</p>
        </div>
        <div class="stat-card">
          <h3>Total Revenue</h3>
          <p>{{ getTotalRevenue() | currency }}</p>
        </div>
      </div>

      <div class="transactions-list">
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Item</th>
              <th>Amount</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            <tr *ngFor="let transaction of transactions">
              <td>{{ transaction.id }}</td>
              <td>{{ transaction.itemName }}</td>
              <td>{{ transaction.amount | currency }}</td>
              <td>{{ transaction.timestamp | date:'medium' }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  `,
  styles: [`
    .admin-transactions {
      padding: 20px;
      max-width: 1200px;
      margin: 0 auto;
    }

    .transactions-stats {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 20px;
      margin: 20px 0;
    }

    .stat-card {
      background: white;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
      text-align: center;
    }

    .stat-card h3 {
      margin: 0 0 10px 0;
      color: #2c3e50;
    }

    .stat-card p {
      margin: 0;
      font-size: 24px;
      font-weight: bold;
      color: #3498db;
    }

    .transactions-list {
      background: white;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
      overflow-x: auto;
    }

    table {
      width: 100%;
      border-collapse: collapse;
    }

    th, td {
      padding: 12px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }

    th {
      background-color: #f8f9fa;
      font-weight: bold;
      color: #2c3e50;
    }

    tr:hover {
      background-color: #f5f5f5;
    }
  `]
})
export class AdminTransactionsComponent implements OnInit {
  transactions: Transaction[] = [];

  constructor(private transactionService: TransactionService) {}

  ngOnInit() {
    this.transactionService.getTransactions().subscribe(
      transactions => this.transactions = transactions
    );
  }

  getTotalRevenue(): number {
    return this.transactions.reduce((total, t) => total + t.amount, 0);
  }
}