import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AuthService } from '../../../services/auth.service';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <div class="admin-dashboard">
      <h2>Admin Dashboard</h2>
      
      <div class="admin-nav">
        <a routerLink="/admin/menu" class="nav-item">
          <h3>Menu Management</h3>
          <p>Add, edit, or remove menu items</p>
        </a>
        
        <a routerLink="/admin/transactions" class="nav-item">
          <h3>Transactions</h3>
          <p>View all transaction history</p>
        </a>
      </div>

      <button class="logout-btn" (click)="logout()">Logout</button>
    </div>
  `,
  styles: [`
    .admin-dashboard {
      padding: 20px;
      max-width: 1200px;
      margin: 0 auto;
    }

    .admin-nav {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 20px;
      margin-top: 20px;
    }

    .nav-item {
      background: white;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
      text-decoration: none;
      color: inherit;
      transition: transform 0.2s;
    }

    .nav-item:hover {
      transform: translateY(-2px);
    }

    .nav-item h3 {
      margin: 0 0 10px 0;
      color: #2c3e50;
    }

    .nav-item p {
      margin: 0;
      color: #666;
    }

    .logout-btn {
      margin-top: 20px;
      background-color: #e74c3c;
    }

    .logout-btn:hover {
      background-color: #c0392b;
    }
  `]
})
export class AdminDashboardComponent {
  constructor(private authService: AuthService) {}

  logout() {
    this.authService.logout();
  }
}