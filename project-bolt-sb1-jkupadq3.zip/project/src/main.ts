import { Component } from '@angular/core';
import { bootstrapApplication } from '@angular/platform-browser';
import { provideRouter } from '@angular/router';
import { routes } from './app/app.routes';
import { AuthService } from './app/services/auth.service';

@Component({
  selector: 'app-root',
  template: `
    <header>
      <h1>Student Food Planner</h1>
      <nav>
        <a routerLink="/home">Home</a>
        <a routerLink="/suggestions">Suggestions</a>
        <a routerLink="/menu">Menu</a>
        <a routerLink="/settings">Settings</a>
        <ng-container *ngIf="!isAdmin">
          <a (click)="login()">Admin Login</a>
        </ng-container>
        <ng-container *ngIf="isAdmin">
          <a routerLink="/admin">Admin Dashboard</a>
        </ng-container>
      </nav>
    </header>
    <main>
      <router-outlet></router-outlet>
    </main>
  `,
  styles: [`
    header {
      background-color: #2c3e50;
      color: white;
      padding: 1rem;
      margin-bottom: 2rem;
    }
    h1 {
      margin: 0;
      font-size: 1.5rem;
    }
    nav {
      margin-top: 1rem;
    }
    nav a {
      color: white;
      text-decoration: none;
      margin-right: 1rem;
      cursor: pointer;
    }
    nav a:hover {
      text-decoration: underline;
    }
    nav a.active {
      font-weight: bold;
    }
    main {
      padding: 0 1rem;
    }
  `],
  imports: [RouterOutlet, RouterLink, CommonModule],
  standalone: true
})
export class App {
  name = 'Food Planner';
  isAdmin = false;

  constructor(private authService: AuthService) {
    this.isAdmin = this.authService.isAdmin();
  }

  login() {
    const password = prompt('Enter admin password:');
    if (password && this.authService.login(password)) {
      this.isAdmin = true;
    }
  }
}

bootstrapApplication(App, {
  providers: [
    provideRouter(routes)
  ]
}).catch(err => console.error(err));